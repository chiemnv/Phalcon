
<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
	<div class="row">
		<ol class="breadcrumb">
			<li><a href="#"><svg class="glyph stroked home"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#stroked-home"></use></svg></a></li>
			<li class="active">Danh mục</li>
		</ol>
	</div><!--/.row-->


	<div class="row">
		<div class="col-md-12">
			<div class="panel panel-default">
				<div class="panel-heading">Danh mục</div>
				<div class="panel-body">
					<table data-toggle="table" class="table table-hover">
						<thead>
						<tr>
							<td>Id</td>
							<td>Tiêu đề</td>
							<td>Edit</td>
							<td>Delete</td>
						</tr>
						</thead>
						<tbody>
						<?= $cattree ?>

                        
							
								
								
								
								
							
                        

						</tbody>
					</table>
                    
					<a href="/index/add/" class="btn btn-primary">Thêm mới</a>

				</div>
			</div>
		</div>

	</div><!--/.row-->



