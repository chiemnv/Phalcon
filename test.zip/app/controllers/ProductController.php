<?php
//use Cafe\Backend\Models\Category;
//use Cafe\Backend\Models\User;
//use library\Helper;
class ProductController extends ControllerBase {
    /*
     * Show list user in database
     */
    public function indexAction() {
        $category = new Product ();
        $limit = 10;
        $p = $this->request->get("p");
        if ($p <= 1) $p = 1;

        $cp = Helper::offset($p, $limit);

        $query = "id > 0 ";
        $product = Product::find([
            "conditions" => $query,
            "order" => "id ASC",
            "limit" => $limit,
            "offset" => $cp
        ]);
        //$product = Product::find();
        $this->view->product = $product;
        //echo $p;die;
        $this->view->painginfo = Helper::paginginfo(Product::count($query), $limit, $p);

    }
    /* product
     * Show detail information of user
     */
    public function showAction($catId) {
        $this->view->user = Product::findFirst ( $catId );
    }
    /*
     * Delete a user by Id
     */
    public function deleteAction($Id) {
        $pro = new Product ();
        $pro->id = $Id;
        $pro->delete ();
        $this->response->redirect('/product/index');
    }
    /*
     * Add new user to database
     */
    public function addAction() {
        if ($this->request->isPost ()) {
            $category = new Product ();
            $category->name = $this->request->get( "name" );
            $category->catid = $this->request->get ( "catid" );
            $category->image = $this->request->get ( "image" );
            $category->des = $this->request->get ( "des" );
            $category->content = $this->request->get ( "content" );
            $category->save ();
            $this->response->redirect('/product/index');
            //return $this->dispatcher->forward ( array ('action' => 'index') );
        }
        $products = Product::find("1=1 order by id ASC");
        $cattree = self::getMenu(0);
        //var_dump($cattree);die;
        $this->view->cattree = $cattree;
    }


    public function getMenu($parentid,$parentID_get) {
        //$category = new Categories ();
        $listdata = Categories::find("parent_id=$parentid");
        $listdata = $listdata->toArray();
        if (!$listdata) return null;
        $html = "";
        foreach ($listdata as $row) {
            //echo $parentid;die;
            if(count($parentID_get)){
                if($parentID_get == $row['id']){
                    $_seleted = 'selected';
                }
                else{
                    $_seleted = '';
                }
            }
            $str = "";
            for ($i = 0; $i < $row['level']; $i++) $str .= "---";
            $html .= "<option {$_seleted} value=\"{$row['id']}\">$str{$row['name']} ";
            $html .= self::getMenu($row['id'],$parentID_get);
            $html .= "</option>";
        }
        $html .= "";

        return $html;
    }
    /*
     * Update a user in database by id
     */
    public function updateAction($Id) {
        // When submit information of user
        if ($this->request->isPost ()) {
            $products = Product::findFirst ( $this->request->get("id") );
            //$updateUser = $this->request->get("id");
            $products->name = $this->request->get ( "name" );
            $products->catid = $this->request->get ( "catid" );
            $products->image = $this->request->get ( "image" );
            $products->des = $this->request->get ( "des" );
            $products->content = $this->request->get ( "content" );
            $products->save ();
            $this->response->redirect('/product/index');

        } else {
            //$this->request->get("id");
            $parentID_get = Product::findFirst ($this->request->get("id"))->catid;
           // echo $parentID_get;die;
            $cattree = self::getMenu(0,$parentID_get);
            //echo $cattree;die;
            $this->view->cattree = $cattree;
            $this->view->product = Product::findFirst ( $this->request->get("id") );
            //$this->view->product_parentID = Product::find ();

        }

        $user = Users::findFirst(
            [
                "(email = :email: OR username = :email:) AND password = :password: AND active = 'Y'",
                "bind" => [
                    "email"    => $email,
                    "password" => sha1($password),
                ]
            ]
        );
    }
}

