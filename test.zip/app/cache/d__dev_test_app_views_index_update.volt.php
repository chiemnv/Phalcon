

<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
    <div class="row">
        <ol class="breadcrumb">
            <li><a href="#"><svg class="glyph stroked home"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#stroked-home"></use></svg></a></li>
            <li class="active">Sửa danh mục</li>
        </ol>
    </div><!--/.row-->


    <div class="row">
        <div class="col-md-12">
            <form method="post" action="update">
                <br/>
                <div class="form-group">
                    <label>Tiêu đề</label>
                    <input class="form-control" value="<?= $categories->name ?>" name="name">
                </div>
                <div class="form-group">
                    <label>Chọn danh mục</label>
                    <select name="parent_id" class="form-control" >
                        <option value="0">Chọn danh mục cha</option>
                        <?= $cattree ?>
                    </select>
                </div>
                <input type="submit" name="submit" class="btn btn-primary" >
                <input type="hidden" name="id" value="<?= $categories->id ?>">

            </form>
        </div>

    </div><!--/.row-->

