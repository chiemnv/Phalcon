<?php

use Phalcon\Http\Request as RQ;

class Helper
{
    public static function paginginfo($rowcount, $limit, $page, $pagelimit = 3) {
        if ($page <= 1) $page = 1;
        $totalpage = ceil($rowcount / $limit);
        $startpaging = $page - $pagelimit;
        if ($startpaging <= 1) $startpaging = 1;
        $endpaging = $page + $pagelimit;
        if ($endpaging >= $totalpage) $endpaging = $totalpage;
        if ($endpaging <= $startpaging) $endpaging = $startpaging = 1;
        $paginginfo = [
            "rowcount" => $rowcount,
            "rangepage" => range($startpaging, $endpaging),
            "totalpage" => $totalpage,
            "page" => $page,
            "currentlink" => Helper::cpagerparm("p"),
            "maxpage" => $pagelimit,
            "limit" => $limit
        ];

        return $paginginfo;
    }

    public static function offset($page, $limit)
    {
        if ($page <= 1) $page = 1;
        $offset = ($page - 1) * $limit;
        return $offset;
    }
    public static function cpagerparm($para_need_remove, $suffixctr = null) {
        $request = new \Phalcon\Http\Request;
        $pa = $request->getQuery();
        $controller = $pa['_url'];
        unset($pa['_url']);
        ##Remove Item
        $s = explode(',', $para_need_remove);
        foreach ($s as $item) unset($pa["$item"]);
        ## Append Querystring
        $str = '';
        foreach ($pa as $key => $val) {
            if (is_array($val)) {
                foreach ($val as $sitem) $hs .= $key . '[]=' . $sitem . '&';
                $str .= $hs;
            }
            else $str .= $key . '=' . $val . '&';
        }
        if ($suffixctr == null) $link = $controller . "?" . $str;
        else $link = $suffixctr . "?" . $str;
        $link = rtrim($link, "&");

        return $link;
    }
}