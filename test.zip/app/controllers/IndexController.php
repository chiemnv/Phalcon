<?php
//use Cafe\Backend\Models\Category;
//use Cafe\Backend\Models\User;
//use library\Helper;
class IndexController extends ControllerBase {
	/*
	 * Show list user in database
	 */
	public function indexAction() {

		$category = new Categories ();
        $limit = 7;
        $p = $this->request->get("p");
        if ($p <= 1) $p = 1;

        $cp = Helper::offset($p, $limit);

        $query = "id > 0 ";
        /*$categories = Categories::find([
            "conditions" => $query,
            "order" => "id ASC",
            "limit" => $limit,
            "offset" => $cp
        ]);
        */
        $categories = Categories::find();
        print_r($this->db->getSqlVariables());
        $this->view->categories = $categories;
        //echo $p;die;
        $this->view->painginfo = Helper::paginginfo(Categories::count($query), $limit, $p);
        $cattree = self::getMenu_show(0);
        $this->view->cattree = $cattree;


	}
	/*
	 * Show detail information of user
	 */
	public function showAction($catId) {
		$this->view->user = Categories::findFirst ( $catId );
	}
	/*
	 * Delete a user by Id
	 */
	public function deleteAction($catId) {
		$user = new Categories ();
		$user->id = $catId;
		$user->delete ();
		return $this->dispatcher->forward ( array (
				'action' => 'index' 
		) );
	}
	/*
	 * Add new user to database
	 */
	public function addAction() {
		if ($this->request->isPost ()) {
			$category = new Categories ();
            $category->name = $this->request->get ( "name" );
            $category->parent_id = $this->request->get ( "parent_id" );
            $listparent = Categories::findFirst($this->request->get ( "parent_id" ));
            if($this->request->get ( "parent_id" ) != 0){
                $category->level = $listparent->level +1;
            }
            else{
                $category->level = 0;
            }
            // select level from categories where id = $this->request->get ( "parent_id" )

            $category->save ();
            $this->response->redirect('/index');
            //return $this->dispatcher->forward ( array ('action' => 'index') );

		}
        $cat_list = Categories::find("1=1 order by id ASC");

        $cattree = self::getMenu(0);
        $this->view->cattree = $cattree;


	}

    public function getMenu_show($parentid,$parentID_get) {
        $listdata = Categories::find("parent_id=$parentid");
        $listdata = $listdata->toArray();
        if (!$listdata) return null;
        $html = "";
        foreach ($listdata as $row) {
            //echo $parentid;die;
            if(count($parentID_get)){
                if($parentID_get == $row['id']){
                    $_seleted = 'selected';
                }
                else{
                    $_seleted = '';
                }
            }
            $str = "";
            for ($i = 0; $i < $row['level']; $i++) $str .= "/---";

            $html .= "<tr><td>{$row['id']}</td> ";
            $html .= "<td>$str{$row['name']}</td> ";
            $html .= "<td><a href=\"/index/update?id={$row['id']}\">Update</a></td> ";
            $html .= "<td><a href=\"/index/delete/{$row['id']}\">Delete</a></td> ";
            $html .= self::getMenu_show($row['id'],$parentID_get);
            $html .= "</tr>";
        }
        $html .= "";

        return $html;
    }

    public function getMenu($parentid,$parentID_get) {
        $listdata = Categories::find("parent_id=$parentid");
        $listdata = $listdata->toArray();
        if (!$listdata) return null;
        $html = "";
        foreach ($listdata as $row) {
            //echo $parentid;die;
            if(count($parentID_get)){
                if($parentID_get == $row['id']){
                    $_seleted = 'selected';
                }
                else{
                    $_seleted = '';
                }
            }
            $str = "";
            for ($i = 0; $i < $row['level']; $i++) $str .= "---";
            $html .= "<option {$_seleted} value=\"{$row['id']}\">$str{$row['name']} ";
            $html .= self::getMenu($row['id'],$parentID_get);
            $html .= "</option>";
        }
        $html .= "";

        return $html;
    }
	/*
	 * Update a user in database by id
	 */
	public function updateAction($catId) {
		// When submit information of user

		if ($this->request->isPost ()) {
            $category = Categories::findFirst ( $this->request->get ("id") );
            //$updateUser = $this->request->get("id");
            $category->name = $this->request->get ( "name" );
            $category->parent_id = $this->request->get ( "parent_id" );
            $listparent = Categories::findFirst($this->request->get ( "parent_id" ));
            if($this->request->get ( "parent_id" ) != 0){
                $category->level = $listparent->level +1;
            }
            else{
                $category->level = 0;
            }
            $category->save ();

            $this->response->redirect('/index');

		} else {

            //$this->request->get("id");
            $parentID_get = Categories::findFirst ($this->request->get("id"))->parent_id;
            $cattree = self::getMenu(0,$parentID_get);
            //echo $cattree;die;
            $this->view->cattree = $cattree;
			$this->view->categories = Categories::findFirst ( $this->request->get("id") );

            //$this->view->categories_parentID = Categories::find ();

		}
	}
}

